import React, { useState } from 'react';
import { Button, DatePicker, Input, Form, Checkbox } from 'antd';
import { UserOutlined } from '@ant-design/icons';
import './App.css';



const App = () => {
  const [newItem, setNewItem] = useState('')
  const [list, setList] = useState([]);




  const addItem = (todoValue) => {
    if (todoValue !== "") {
      const newItem = {
        id: Date.now(),
        value: todoValue,
        isDone: false
      }
      const lists = [...list];
      lists.push(newItem)

      setNewItem(newItem)
      setList(lists)
    }
    else {
      alert("please enter item")
    }

  }

  const updateInput = (event) => {
    setNewItem({
      newItem: event.target.value
    })

  }


  console.log("itemss==>>", list)

  return (
    <div className="container">
      <img
        className="imgStyle"
        width="100"
        height="100"
        src="https://cdn.pixabay.com/photo/2015/09/21/23/18/youtube-950900__340.png"
      />

      <main className="mainStyle" >

        <div className="headingStyle" >
          <p>LCO ToDO App</p>
        </div>
        <p>Add an item...</p>


        <div className="buttonStyle">
          <Input
            size="large"
            placeholder="Write a todo"
            style={{
              borderRadius: 8,
              height: 48
            }}
            onChange={updateInput}

          />

          <Button
            style={{
              height: 48,
              borderRadius: 8,
              marginLeft: 8
            }}
            onClick={() => addItem(newItem)}
          >
            ADD TODO
        </Button>

        </div>

        <div style={{ marginTop: 24 }}>
          <ul>

            {
              list.map(item => {
                return (
                  <li key={item.id}>{item.value}</li>
                )
              })
            }

          </ul>
        </div>


      </main>
    </div>
  )
};

export default App;